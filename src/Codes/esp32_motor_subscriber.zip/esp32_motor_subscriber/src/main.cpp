#include <Arduino.h>
#include <math.h>
#include <Wire.h>
#include <ESP32Servo.h>
#include <VL53L0X.h>
#include <SparkFun_BNO08x_Arduino_Library.h>

#include <micro_ros_platformio.h>
#include <rcl/rcl.h>
#include <rcl/error_handling.h>
#include <rclc/rclc.h>
#include <rclc/executor.h>

#include <geometry_msgs/msg/twist.h>
#include <sensor_msgs/msg/laser_scan.h>
#include <sensor_msgs/msg/imu.h>
#include <nav_msgs/msg/odometry.h>

// ============================================================
// Hardware Configuration
// ============================================================

#define STATUS_LED 2

// BTS7960 motor driver pins
#define RPWM   25
#define LPWM   26
#define R_EN   27
#define L_EN   14

// Steering servo configuration
#define SERVO_PIN    13
#define SERVO_CENTER 90
#define SERVO_MIN    45
#define SERVO_MAX    135

// Motor PWM configuration
#define PWM_FREQ        5000
#define PWM_RESOLUTION  8
#define RPWM_CHANNEL    0
#define LPWM_CHANNEL    1

// VL53L0X sensor I2C and XSHUT configuration
#define TOF_SDA          21
#define TOF_SCL          22
#define TOF_XSHUT_LEFT   32
#define TOF_XSHUT_FRONT  33
#define TOF_XSHUT_RIGHT  4
#define TOF_XSHUT_BACK   15

// Individual I2C addresses assigned during sensor initialization
#define TOF_ADDR_LEFT    0x30
#define TOF_ADDR_FRONT   0x31
#define TOF_ADDR_RIGHT   0x32
#define TOF_ADDR_BACK    0x33

#define TOF_PERIOD_MS    20

// BNO086 configuration
#define IMU_I2C_ADDR   0x4A
#define IMU_PERIOD_MS  20

// ============================================================
// micro-ROS Entities
// ============================================================

#define RCCHECK(fn) \
  { rcl_ret_t temp_rc = (fn); if (temp_rc != RCL_RET_OK) { error_loop(); } }

#define RCSOFTCHECK(fn) \
  { rcl_ret_t temp_rc = (fn); (void)temp_rc; }

rcl_subscription_t subscriber;
geometry_msgs__msg__Twist twist_msg;

rcl_publisher_t tof_left_pub;
rcl_publisher_t tof_front_pub;
rcl_publisher_t tof_right_pub;
rcl_publisher_t tof_back_pub;
rcl_publisher_t imu_pub;
rcl_publisher_t odom_pub;

nav_msgs__msg__Odometry odom_msg;

sensor_msgs__msg__LaserScan tof_left_msg;
sensor_msgs__msg__LaserScan tof_front_msg;
sensor_msgs__msg__LaserScan tof_right_msg;
sensor_msgs__msg__LaserScan tof_back_msg;

sensor_msgs__msg__Imu imu_msg;

// ROS frame identifiers
const char* TOF_FRAME_LEFT  = "tof_left";
const char* TOF_FRAME_FRONT = "tof_front";
const char* TOF_FRAME_RIGHT = "tof_right";
const char* TOF_FRAME_BACK  = "tof_back";
const char* IMU_FRAME       = "imu_link";

rclc_executor_t executor;
rclc_support_t  support;
rcl_allocator_t allocator;
rcl_node_t      node;

// ============================================================
// Sensors and Actuators
// ============================================================

VL53L0X tof_left;
VL53L0X tof_front;
VL53L0X tof_right;
VL53L0X tof_back;

BNO08x imu;

Servo steering_servo;

// ============================================================
// Motor Control
// ============================================================

void motor_stop() {
  ledcWrite(RPWM_CHANNEL, 0);
  ledcWrite(LPWM_CHANNEL, 0);
}

// Drives the motor using a normalized command:
// -1.0 = full reverse, 0.0 = stop, +1.0 = full forward
void motor_drive(float speed) {
  speed = constrain(speed, -1.0f, 1.0f);
  int duty = (int)(fabsf(speed) * 255.0f);

  if (speed > 0.01f) {
    ledcWrite(LPWM_CHANNEL, 0);
    ledcWrite(RPWM_CHANNEL, duty);
  } else if (speed < -0.01f) {
    ledcWrite(RPWM_CHANNEL, 0);
    ledcWrite(LPWM_CHANNEL, duty);
  } else {
    motor_stop();
  }
}

// ============================================================
// Steering Control
// ============================================================

// Maps the normalized angular command to the physical
// steering range of the servo.
// -1.0 = maximum left, 0.0 = center, +1.0 = maximum right
void servo_steer(float angular_z) {
  angular_z = constrain(angular_z, -1.0f, 1.0f);

  int angle = SERVO_CENTER +
              (int)(angular_z * (float)(SERVO_MAX - SERVO_CENTER));

  angle = constrain(angle, SERVO_MIN, SERVO_MAX);
  steering_servo.write(angle);
}

// ============================================================
// System Error Handler
// ============================================================

// Places the actuator system in a safe state and indicates
// a fatal initialization or runtime error using the status LED.
void error_loop() {
  motor_stop();
  steering_servo.write(SERVO_CENTER);

  while (true) {
    digitalWrite(STATUS_LED, !digitalRead(STATUS_LED));
    delay(100);
  }
}

// ============================================================
// ROS Command Callback
// ============================================================

// Processes incoming geometry_msgs/Twist commands from cmd_vel.
void cmd_vel_callback(const void* msgin) {
  const geometry_msgs__msg__Twist* msg =
      (const geometry_msgs__msg__Twist*)msgin;

  motor_drive((float)msg->linear.x);
  servo_steer((float)msg->angular.z);
}

// ============================================================
// VL53L0X Message Initialization
// ============================================================

// Initializes a LaserScan message for a single-point distance
// measurement. Each sensor publishes one range value.
void tof_init_msg(sensor_msgs__msg__LaserScan* msg,
                  const char* frame_id) {
  msg->header.frame_id.capacity = strlen(frame_id) + 1;
  msg->header.frame_id.size     = strlen(frame_id);
  msg->header.frame_id.data     =
      (char*)malloc(msg->header.frame_id.capacity);

  memcpy(msg->header.frame_id.data,
         frame_id,
         msg->header.frame_id.capacity);

  msg->angle_min       = 0.0f;
  msg->angle_max       = 0.0f;
  msg->angle_increment = 0.0f;

  msg->range_min = 0.03f;
  msg->range_max = 1.2f;

  msg->ranges.capacity = 1;
  msg->ranges.size     = 1;
  msg->ranges.data     = (float*)malloc(sizeof(float));

  msg->ranges.data[0] = INFINITY;
}

// Initializes the four VL53L0X sensors using the XSHUT pins
// and assigns unique I2C addresses to each device.
void tof_setup() {
  Wire.begin(TOF_SDA, TOF_SCL);
  Wire.setClock(400000);

  pinMode(TOF_XSHUT_LEFT,  OUTPUT);
  pinMode(TOF_XSHUT_FRONT, OUTPUT);
  pinMode(TOF_XSHUT_RIGHT, OUTPUT);
  pinMode(TOF_XSHUT_BACK,  OUTPUT);

  // Disable all sensors before assigning individual addresses.
  digitalWrite(TOF_XSHUT_LEFT,  LOW);
  digitalWrite(TOF_XSHUT_FRONT, LOW);
  digitalWrite(TOF_XSHUT_RIGHT, LOW);
  digitalWrite(TOF_XSHUT_BACK,  LOW);

  delay(10);

  // Initialize the left sensor and assign its unique address.
  digitalWrite(TOF_XSHUT_LEFT, HIGH);
  delay(10);

  tof_left.init();
  tof_left.setAddress(TOF_ADDR_LEFT);
  tof_left.setTimeout(500);
  tof_left.startContinuous(TOF_PERIOD_MS);

  // Initialize the front sensor and assign its unique address.
  digitalWrite(TOF_XSHUT_FRONT, HIGH);
  delay(10);

  tof_front.init();
  tof_front.setAddress(TOF_ADDR_FRONT);
  tof_front.setTimeout(500);
  tof_front.startContinuous(TOF_PERIOD_MS);

  // Initialize the right sensor and assign its unique address.
  digitalWrite(TOF_XSHUT_RIGHT, HIGH);
  delay(10);

  tof_right.init();
  tof_right.setAddress(TOF_ADDR_RIGHT);
  tof_right.setTimeout(500);
  tof_right.startContinuous(TOF_PERIOD_MS);

  // Initialize the rear sensor and assign its unique address.
  digitalWrite(TOF_XSHUT_BACK, HIGH);
  delay(10);

  tof_back.init();
  tof_back.setAddress(TOF_ADDR_BACK);
  tof_back.setTimeout(500);
  tof_back.startContinuous(TOF_PERIOD_MS);
}

// ============================================================
// VL53L0X Data Publishing
// ============================================================

// Reads all four distance sensors and publishes their values
// as individual LaserScan messages.
void tof_publish() {
  float r_left =
      tof_left.readRangeContinuousMillimeters() / 1000.0f;

  float r_front =
      tof_front.readRangeContinuousMillimeters() / 1000.0f;

  float r_right =
      tof_right.readRangeContinuousMillimeters() / 1000.0f;

  float r_back =
      tof_back.readRangeContinuousMillimeters() / 1000.0f;

  // Measurements outside the configured operating range or
  // measurements that timed out are represented as infinity.
  tof_left_msg.ranges.data[0] =
      (r_left > 1.2f || tof_left.timeoutOccurred())
          ? INFINITY
          : r_left;

  tof_front_msg.ranges.data[0] =
      (r_front > 1.2f || tof_front.timeoutOccurred())
          ? INFINITY
          : r_front;

  tof_right_msg.ranges.data[0] =
      (r_right > 1.2f || tof_right.timeoutOccurred())
          ? INFINITY
          : r_right;

  tof_back_msg.ranges.data[0] =
      (r_back > 1.2f || tof_back.timeoutOccurred())
          ? INFINITY
          : r_back;

  // Use the same timestamp for all four sensor measurements.
  struct timespec ts;
  clock_gettime(CLOCK_REALTIME, &ts);

  tof_left_msg.header.stamp.sec     = ts.tv_sec;
  tof_left_msg.header.stamp.nanosec = ts.tv_nsec;

  tof_front_msg.header.stamp = tof_left_msg.header.stamp;
  tof_right_msg.header.stamp = tof_left_msg.header.stamp;
  tof_back_msg.header.stamp  = tof_left_msg.header.stamp;

  RCSOFTCHECK(
      rcl_publish(&tof_left_pub, &tof_left_msg, NULL));

  RCSOFTCHECK(
      rcl_publish(&tof_front_pub, &tof_front_msg, NULL));

  RCSOFTCHECK(
      rcl_publish(&tof_right_pub, &tof_right_msg, NULL));

  RCSOFTCHECK(
      rcl_publish(&tof_back_pub, &tof_back_msg, NULL));
}

// Maintains the configured VL53L0X publishing period
// without blocking the main control loop.
void tof_spin() {
  static unsigned long last_tof_time = 0;
  unsigned long now = millis();

  if (now - last_tof_time < TOF_PERIOD_MS) {
    return;
  }

  last_tof_time = now;
  tof_publish();
}

// ============================================================
// BNO086 Message Initialization
// ============================================================

// Initializes the ROS IMU message and marks covariance matrices
// as unavailable until valid sensor data is received.
void imu_init_msg(sensor_msgs__msg__Imu* msg,
                  const char* frame_id) {
  msg->header.frame_id.capacity = strlen(frame_id) + 1;
  msg->header.frame_id.size     = strlen(frame_id);
  msg->header.frame_id.data     =
      (char*)malloc(msg->header.frame_id.capacity);

  memcpy(msg->header.frame_id.data,
         frame_id,
         msg->header.frame_id.capacity);

  msg->orientation.x = 0.0;
  msg->orientation.y = 0.0;
  msg->orientation.z = 0.0;
  msg->orientation.w = 1.0;

  for (int i = 0; i < 9; i++) {
    msg->orientation_covariance[i] = -1.0;
  }

  msg->angular_velocity.x = 0.0;
  msg->angular_velocity.y = 0.0;
  msg->angular_velocity.z = 0.0;

  for (int i = 0; i < 9; i++) {
    msg->angular_velocity_covariance[i] = -1.0;
  }

  msg->linear_acceleration.x = 0.0;
  msg->linear_acceleration.y = 0.0;
  msg->linear_acceleration.z = 0.0;

  for (int i = 0; i < 9; i++) {
    msg->linear_acceleration_covariance[i] = -1.0;
  }
}

// Initializes the BNO086 over the shared I2C bus and enables
// the rotation-vector report at the configured update rate.
void imu_setup() {
  // The RESET and INT lines are not connected in this hardware configuration.
  if (!imu.begin(IMU_I2C_ADDR, Wire)) {
    error_loop();
  }

  imu.enableRotationVector(IMU_PERIOD_MS);
}

// Publishes the latest BNO086 orientation as a ROS Imu message.
void imu_publish() {
  imu_msg.orientation.x = imu.getQuatI();
  imu_msg.orientation.y = imu.getQuatJ();
  imu_msg.orientation.z = imu.getQuatK();
  imu_msg.orientation.w = imu.getQuatReal();

  // Convert the reported quaternion angular accuracy into
  // an equivalent variance for the ROS covariance matrix.
  float rad_acc = imu.getQuatRadianAccuracy();
  float var = rad_acc * rad_acc;

  memset(
      imu_msg.orientation_covariance,
      0,
      sizeof(imu_msg.orientation_covariance));

  imu_msg.orientation_covariance[0] = var;
  imu_msg.orientation_covariance[4] = var;
  imu_msg.orientation_covariance[8] = var;

  struct timespec ts;
  clock_gettime(CLOCK_REALTIME, &ts);

  imu_msg.header.stamp.sec     = ts.tv_sec;
  imu_msg.header.stamp.nanosec = ts.tv_nsec;

  RCSOFTCHECK(
      rcl_publish(&imu_pub, &imu_msg, NULL));
}

// Polls the BNO086 without busy-waiting and publishes only
// rotation-vector reports.
void imu_spin() {
  static unsigned long last_imu_time = 0;
  unsigned long now = millis();

  if (now - last_imu_time < IMU_PERIOD_MS) {
    return;
  }

  last_imu_time = now;

  if (!imu.getSensorEvent()) {
    return;
  }

  if (imu.getSensorEventID() != SENSOR_REPORTID_ROTATION_VECTOR) {
    return;
  }

  imu_publish();
}

// ============================================================
// System Initialization
// ============================================================

void setup() {
  Serial.begin(115200);

  // Initialize the status LED.
  pinMode(STATUS_LED, OUTPUT);
  digitalWrite(STATUS_LED, LOW);

  // Enable both BTS7960 half-bridges.
  pinMode(R_EN, OUTPUT);
  pinMode(L_EN, OUTPUT);

  digitalWrite(R_EN, HIGH);
  digitalWrite(L_EN, HIGH);

  // Configure the two motor PWM channels.
  ledcSetup(
      RPWM_CHANNEL,
      PWM_FREQ,
      PWM_RESOLUTION);

  ledcSetup(
      LPWM_CHANNEL,
      PWM_FREQ,
      PWM_RESOLUTION);

  ledcAttachPin(RPWM, RPWM_CHANNEL);
  ledcAttachPin(LPWM, LPWM_CHANNEL);

  motor_stop();

  // Allocate a dedicated ESP32 hardware timer for the steering servo.
  ESP32PWM::allocateTimer(2);

  steering_servo.setPeriodHertz(50);
  steering_servo.attach(SERVO_PIN, 500, 2400);
  steering_servo.write(SERVO_CENTER);

  // Initialize the four VL53L0X distance sensors.
  tof_setup();

  // Initialize the BNO086 IMU.
  imu_setup();

  // Configure the serial transport used by micro-ROS.
  set_microros_serial_transports(Serial);
  delay(2000);

  allocator = rcl_get_default_allocator();

  // Initialize the micro-ROS support layer and node.
  RCCHECK(
      rclc_support_init(
          &support,
          0,
          NULL,
          &allocator));

  RCCHECK(
      rclc_node_init_default(
          &node,
          "esp32_robot",
          "",
          &support));

  // Create the cmd_vel subscriber.
  RCCHECK(
      rclc_subscription_init_default(
          &subscriber,
          &node,
          ROSIDL_GET_MSG_TYPE_SUPPORT(
              geometry_msgs,
              msg,
              Twist),
          "cmd_vel"));

  // Create publishers for the four distance sensors.
  RCCHECK(
      rclc_publisher_init_default(
          &tof_left_pub,
          &node,
          ROSIDL_GET_MSG_TYPE_SUPPORT(
              sensor_msgs,
              msg,
              LaserScan),
          "/tof_left"));

  RCCHECK(
      rclc_publisher_init_default(
          &tof_front_pub,
          &node,
          ROSIDL_GET_MSG_TYPE_SUPPORT(
              sensor_msgs,
              msg,
              LaserScan),
          "/tof_front"));

  RCCHECK(
      rclc_publisher_init_default(
          &tof_right_pub,
          &node,
          ROSIDL_GET_MSG_TYPE_SUPPORT(
              sensor_msgs,
              msg,
              LaserScan),
          "/tof_right"));

  RCCHECK(
      rclc_publisher_init_default(
          &tof_back_pub,
          &node,
          ROSIDL_GET_MSG_TYPE_SUPPORT(
              sensor_msgs,
              msg,
              LaserScan),
          "/tof_back"));

  // Create the IMU publisher.
  RCCHECK(
      rclc_publisher_init_default(
          &imu_pub,
          &node,
          ROSIDL_GET_MSG_TYPE_SUPPORT(
              sensor_msgs,
              msg,
              Imu),
          "/imu"));

  // Create the odometry publisher.
  RCCHECK(
      rclc_publisher_init_default(
          &odom_pub,
          &node,
          ROSIDL_GET_MSG_TYPE_SUPPORT(
              nav_msgs,
              msg,
              Odometry),
          "/odom"));

  // Initialize the odometry frame identifier.
  odom_msg.header.frame_id.data     = (char*)"odom";
  odom_msg.header.frame_id.size     = 4;
  odom_msg.header.frame_id.capacity = 5;

  // Initialize all LaserScan messages.
  tof_init_msg(
      &tof_left_msg,
      TOF_FRAME_LEFT);

  tof_init_msg(
      &tof_front_msg,
      TOF_FRAME_FRONT);

  tof_init_msg(
      &tof_right_msg,
      TOF_FRAME_RIGHT);

  tof_init_msg(
      &tof_back_msg,
      TOF_FRAME_BACK);

  // Initialize the IMU message.
  imu_init_msg(
      &imu_msg,
      IMU_FRAME);

  // Configure the executor with the command subscriber.
  // The second handle provides execution capacity for future
  // ROS entities without changing the executor configuration.
  RCCHECK(
      rclc_executor_init(
          &executor,
          &support.context,
          2,
          &allocator));

  RCCHECK(
      rclc_executor_add_subscription(
          &executor,
          &subscriber,
          &twist_msg,
          &cmd_vel_callback,
          ON_NEW_DATA));
}

// ============================================================
// Odometry Publishing
// ============================================================

// Publishes the current odometry state at 50 Hz.
// The current implementation provides the ROS odometry interface
// but does not yet calculate displacement from wheel encoders.
void odom_spin() {
  static unsigned long last_odom_time = 0;
  unsigned long now = millis();

  if (now - last_odom_time < 20) {
    return;
  }

  last_odom_time = now;

  struct timespec ts;
  clock_gettime(CLOCK_REALTIME, &ts);

  odom_msg.header.stamp.sec     = ts.tv_sec;
  odom_msg.header.stamp.nanosec = ts.tv_nsec;

  odom_msg.twist.twist.linear.x = 0.0;

  RCSOFTCHECK(
      rcl_publish(
          &odom_pub,
          &odom_msg,
          NULL));
}

// ============================================================
// Main Control Loop
// ============================================================

void loop() {
  // Process incoming ROS commands without blocking the control loop.
  RCSOFTCHECK(
      rclc_executor_spin_some(
          &executor,
          RCL_MS_TO_NS(10)));

  // Process distance sensors.
  tof_spin();

  // Process IMU data.
  imu_spin();

  // Publish odometry data.
  odom_spin();
}