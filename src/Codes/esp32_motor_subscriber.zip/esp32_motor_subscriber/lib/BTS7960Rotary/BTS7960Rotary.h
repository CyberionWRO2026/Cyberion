#ifndef BTS7960_ROTARY_H
#define BTS7960_ROTARY_H

#include <Arduino.h>

class BTS7960Rotary {
public:
    BTS7960Rotary(int rpwm, int lpwm, int en, int ch_r, int ch_l, int freq);

    void begin();
    void move(float pwm);
    void stop();

private:
    int RPWM, LPWM, EN;
    int CH_R, CH_L;
    int FREQ;
};

#endif

