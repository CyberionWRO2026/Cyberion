#include "BTS7960Rotary.h"

BTS7960Rotary::BTS7960Rotary(int rpwm, int lpwm, int en, int ch_r, int ch_l, int freq)
    : RPWM(rpwm), LPWM(lpwm), EN(en), CH_R(ch_r), CH_L(ch_l), FREQ(freq) {}

void BTS7960Rotary::begin() {
    pinMode(EN, OUTPUT);
    digitalWrite(EN, HIGH);

    ledcSetup(CH_R, FREQ, 8);
    ledcSetup(CH_L, FREQ, 8);

    ledcAttachPin(RPWM, CH_R);
    ledcAttachPin(LPWM, CH_L);

    stop();
}

void BTS7960Rotary::move(float pwm) {
    pwm = constrain(pwm, -255, 255);

    if (pwm > 0) {
        ledcWrite(CH_R, pwm);
        ledcWrite(CH_L, 0);
    } else if (pwm < 0) {
        ledcWrite(CH_R, 0);
        ledcWrite(CH_L, -pwm);
    } else {
        stop();
    }
}

void BTS7960Rotary::stop() {
    ledcWrite(CH_R, 0);
    ledcWrite(CH_L, 0);
}

