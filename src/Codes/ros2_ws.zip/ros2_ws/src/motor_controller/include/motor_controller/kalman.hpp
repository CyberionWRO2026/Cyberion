#ifndef KALMAN_HPP
#define KALMAN_HPP

class KalmanFilter
{
public:
    KalmanFilter();

    double update(double gyro_rate,
                  double accel_angle,
                  double dt);

    void setAngle(double angle);

    double getAngle() const;

private:
    double angle;
    double bias;
    double rate;

    double P[2][2];

    double Q_angle;
    double Q_bias;
    double R_measure;
};

#endif
