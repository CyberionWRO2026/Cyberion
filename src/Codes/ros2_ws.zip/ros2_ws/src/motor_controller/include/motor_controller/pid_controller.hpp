#ifndef MOTOR_CONTROLLER__PID_CONTROLLER_HPP_
#define MOTOR_CONTROLLER__PID_CONTROLLER_HPP_

#include <algorithm>

namespace motor_controller
{

class PidController
{
public:
  PidController() = default;

  void set_gains(double kp, double ki, double kd)
  {
    kp_ = kp;
    ki_ = ki;
    kd_ = kd;
  }

  void set_limits(double integral_clamp, double output_clamp)
  {
    integral_clamp_ = integral_clamp;
    output_clamp_ = output_clamp;
  }

  void reset()
  {
    integral_ = 0.0;
    prev_error_ = 0.0;
    first_update_ = true;
  }

  double update(double error, double dt)
  {
    if (dt <= 0.0) {
      return std::clamp(kp_ * error, -output_clamp_, output_clamp_);
    }

    integral_ += error * dt;
    integral_ = std::clamp(integral_, -integral_clamp_, integral_clamp_);

    double derivative = 0.0;
    if (!first_update_) {
      derivative = (error - prev_error_) / dt;
    }
    prev_error_ = error;
    first_update_ = false;

    double output = kp_ * error + ki_ * integral_ + kd_ * derivative;
    return std::clamp(output, -output_clamp_, output_clamp_);
  }

private:
  double kp_ = 0.0;
  double ki_ = 0.0;
  double kd_ = 0.0;
  double integral_clamp_ = 1.0;
  double output_clamp_ = 1.0;

  double integral_ = 0.0;
  double prev_error_ = 0.0;
  bool first_update_ = true;
};

}  // namespace motor_controller

#endif  // MOTOR_CONTROLLER__PID_CONTROLLER_HPP_
