#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data

from sensor_msgs.msg import Image
from std_msgs.msg import String
from cv_bridge import CvBridge

import cv2
import numpy as np


class CameraSubscriber(Node):

    def __init__(self):
        super().__init__('camera_subscriber')

        self.bridge = CvBridge()

        self._declare_parameters()
        self._read_parameters()

        self.subscription = self.create_subscription(
            Image,
            '/camera',
            self.image_callback,
            qos_profile_sensor_data
        )

        self.color_publisher = self.create_publisher(String, '/detected_color', 10)

        # Debounce state: track consecutive agreeing frames before committing
        # to a new color to avoid flickering on noisy or transitional frames.
        self.candidate_color = 'NONE'
        self.candidate_count = 0
        self.confirmed_color = 'NONE'

        self.get_logger().info('Camera subscriber started (headless)')

    # ---------------------------------------------------------------------------
    #  Parameter declaration and loading
    # ---------------------------------------------------------------------------

    def _declare_parameters(self):
        # Red wraps around the HSV hue circle, so two separate hue ranges are needed.
        self.declare_parameter('red.h1_low',  0)
        self.declare_parameter('red.h1_high', 10)
        self.declare_parameter('red.h2_low',  170)
        self.declare_parameter('red.h2_high', 180)
        self.declare_parameter('red.s_low',   120)
        self.declare_parameter('red.v_low',   70)

        self.declare_parameter('green.h_low',  35)
        self.declare_parameter('green.h_high', 85)
        self.declare_parameter('green.s_low',  80)
        self.declare_parameter('green.v_low',  50)

        self.declare_parameter('magenta.h_low',  140)
        self.declare_parameter('magenta.h_high', 180)
        self.declare_parameter('magenta.s_low',  100)
        self.declare_parameter('magenta.v_low',  100)

        self.declare_parameter('min_area_px2',           1000)
        self.declare_parameter('roi.top_fraction',       0.35)
        self.declare_parameter('downscale.factor',       0.5)
        self.declare_parameter('debounce.required_frames', 3)
        self.declare_parameter('morph.kernel_size',      5)

    def _read_parameters(self):
        gp = self.get_parameter

        # Build NumPy HSV bounds for each color from the declared parameters.
        self.red_lower1 = np.array([gp('red.h1_low').value,  gp('red.s_low').value, gp('red.v_low').value])
        self.red_upper1 = np.array([gp('red.h1_high').value, 255, 255])
        self.red_lower2 = np.array([gp('red.h2_low').value,  gp('red.s_low').value, gp('red.v_low').value])
        self.red_upper2 = np.array([gp('red.h2_high').value, 255, 255])

        self.green_lower = np.array([gp('green.h_low').value,  gp('green.s_low').value, gp('green.v_low').value])
        self.green_upper = np.array([gp('green.h_high').value, 255, 255])

        self.magenta_lower = np.array([gp('magenta.h_low').value,  gp('magenta.s_low').value, gp('magenta.v_low').value])
        self.magenta_upper = np.array([gp('magenta.h_high').value, 255, 255])

        self.min_area_px2            = float(gp('min_area_px2').value)
        self.roi_top_fraction        = float(gp('roi.top_fraction').value)
        self.downscale_factor        = float(gp('downscale.factor').value)
        self.debounce_required_frames = int(gp('debounce.required_frames').value)

        kernel_size      = int(gp('morph.kernel_size').value)
        self.morph_kernel = np.ones((kernel_size, kernel_size), np.uint8)

        # min_area_px2 is expressed in full-resolution pixels. After downscaling
        # by `factor` in both dimensions, the equivalent area shrinks by factor².
        self.scaled_min_area = self.min_area_px2 * (self.downscale_factor ** 2)

    # ---------------------------------------------------------------------------
    #  Image processing helpers
    # ---------------------------------------------------------------------------

    def _mask_for(self, hsv_frame, color):
        """Returns a binary mask isolating the requested color in the HSV frame.

        Red requires two inRange calls because its hue wraps around 180 in
        OpenCV's 0-180 hue encoding; the two masks are OR-combined.
        Raises ValueError for unknown color names to catch typos early.
        """
        if color == 'RED':
            mask1 = cv2.inRange(hsv_frame, self.red_lower1, self.red_upper1)
            mask2 = cv2.inRange(hsv_frame, self.red_lower2, self.red_upper2)
            return cv2.add(mask1, mask2)
        elif color == 'GREEN':
            return cv2.inRange(hsv_frame, self.green_lower, self.green_upper)
        elif color == 'MAGENTA':
            return cv2.inRange(hsv_frame, self.magenta_lower, self.magenta_upper)
        raise ValueError(color)

    @staticmethod
    def _largest_contour(mask):
        """Finds the largest external contour in a binary mask.

        Returns a (contour, area) tuple. If no contours are found, returns
        (None, 0.0) so callers can compare area directly against a threshold
        without additional None guards.
        """
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not contours:
            return None, 0.0
        largest = max(contours, key=cv2.contourArea)
        return largest, cv2.contourArea(largest)

    def _classify(self, frame_bgr):
        """Classifies the dominant color in the lower region of a BGR frame.

        Pipeline:
          1. Crop away the top roi_top_fraction of the frame (sky / ceiling).
          2. Optionally downscale for faster processing.
          3. Convert to HSV and build per-color binary masks.
          4. Apply morphological open+close to remove small noise and fill gaps.
          5. Find the largest contour per color and compare against the area threshold.
          6. Resolve ties (both red and green detected) by keeping the larger blob.

        Returns one of: "RED", "GREEN", "MAGENTA", "NONE".
        """
        h = frame_bgr.shape[0]
        roi_top = int(h * self.roi_top_fraction)
        cropped = frame_bgr[roi_top:, :]

        if self.downscale_factor != 1.0:
            cropped = cv2.resize(
                cropped, None,
                fx=self.downscale_factor, fy=self.downscale_factor,
                interpolation=cv2.INTER_AREA
            )

        hsv = cv2.cvtColor(cropped, cv2.COLOR_BGR2HSV)

        red_mask     = self._mask_for(hsv, 'RED')
        green_mask   = self._mask_for(hsv, 'GREEN')
        magenta_mask = self._mask_for(hsv, 'MAGENTA')

        # Morphological open removes isolated noise pixels; close fills small holes
        # inside the detected blob — both improve contour area reliability.
        red_mask     = cv2.morphologyEx(red_mask,     cv2.MORPH_OPEN,  self.morph_kernel)
        red_mask     = cv2.morphologyEx(red_mask,     cv2.MORPH_CLOSE, self.morph_kernel)
        green_mask   = cv2.morphologyEx(green_mask,   cv2.MORPH_OPEN,  self.morph_kernel)
        green_mask   = cv2.morphologyEx(green_mask,   cv2.MORPH_CLOSE, self.morph_kernel)
        magenta_mask = cv2.morphologyEx(magenta_mask, cv2.MORPH_OPEN,  self.morph_kernel)
        magenta_mask = cv2.morphologyEx(magenta_mask, cv2.MORPH_CLOSE, self.morph_kernel)

        _, red_area     = self._largest_contour(red_mask)
        _, green_area   = self._largest_contour(green_mask)
        _, magenta_area = self._largest_contour(magenta_mask)

        red_detected     = red_area     > self.scaled_min_area
        green_detected   = green_area   > self.scaled_min_area
        magenta_detected = magenta_area > self.scaled_min_area

        # Priority order: red/green tie → largest blob wins; then red, green,
        # magenta. NONE is returned only when no color clears the area threshold.
        if red_detected and green_detected:
            return 'RED' if red_area >= green_area else 'GREEN'
        elif red_detected:
            return 'RED'
        elif green_detected:
            return 'GREEN'
        elif magenta_detected:
            return 'MAGENTA'
        return 'NONE'

    def _debounce(self, raw_color):
        """Suppresses transient color flicker using a consecutive-frame counter.

        A new color is only committed to confirmed_color once it appears in
        debounce_required_frames consecutive frames. If the raw reading changes
        before the threshold is reached, the counter resets to 1.

        Returns the currently confirmed (stable) color.
        """
        if raw_color == self.candidate_color:
            self.candidate_count += 1
        else:
            self.candidate_color = raw_color
            self.candidate_count = 1

        if self.candidate_count >= self.debounce_required_frames:
            self.confirmed_color = self.candidate_color

        return self.confirmed_color

    # ---------------------------------------------------------------------------
    #  ROS 2 callback
    # ---------------------------------------------------------------------------

    def image_callback(self, msg):
        """Converts an incoming Image message, classifies its color, and publishes."""
        try:
            frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        except Exception as e:
            self.get_logger().error(f'cv_bridge conversion failed: {e}')
            return

        raw_color       = self._classify(frame)
        confirmed_color = self._debounce(raw_color)

        out      = String()
        out.data = confirmed_color
        self.color_publisher.publish(out)


# ---------------------------------------------------------------------------
#  Entry point
# ---------------------------------------------------------------------------

def main(args=None):
    rclpy.init(args=args)
    node = CameraSubscriber()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()