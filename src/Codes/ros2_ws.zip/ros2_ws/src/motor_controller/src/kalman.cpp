#include "motor_controller/kalman.hpp"

KalmanFilter::KalmanFilter()
{
    angle = 0.0;
    bias = 0.0;
    rate = 0.0;

    P[0][0] = 0.0;
    P[0][1] = 0.0;
    P[1][0] = 0.0;
    P[1][1] = 0.0;

    Q_angle = 0.001;
    Q_bias = 0.003;
    R_measure = 0.03;
}

double KalmanFilter::update(double gyro_rate,
                            double accel_angle,
                            double dt)
{
    // Prediction
    rate = gyro_rate - bias;
    angle += dt * rate;

    P[0][0] += dt * (dt * P[1][1] - P[0][1] - P[1][0] + Q_angle);
    P[0][1] -= dt * P[1][1];
    P[1][0] -= dt * P[1][1];
    P[1][1] += Q_bias * dt;

    // Innovation
    double S = P[0][0] + R_measure;

    // Kalman Gain
    double K0 = P[0][0] / S;
    double K1 = P[1][0] / S;

    // Update estimate
    double y = accel_angle - angle;

    angle += K0 * y;
    bias += K1 * y;

    // Update covariance
    double P00 = P[0][0];
    double P01 = P[0][1];

    P[0][0] -= K0 * P00;
    P[0][1] -= K0 * P01;
    P[1][0] -= K1 * P00;
    P[1][1] -= K1 * P01;

    return angle;
}

void KalmanFilter::setAngle(double newAngle)
{
    angle = newAngle;
}

double KalmanFilter::getAngle() const
{
    return angle;
}
