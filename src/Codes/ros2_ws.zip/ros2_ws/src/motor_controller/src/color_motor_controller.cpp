#include <algorithm>
#include <cmath>
#include <sstream>
#include <string>

#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/string.hpp>
#include <std_msgs/msg/bool.hpp>
#include <geometry_msgs/msg/twist.hpp>
#include <geometry_msgs/msg/quaternion.hpp>
#include <sensor_msgs/msg/laser_scan.hpp>
#include <sensor_msgs/msg/imu.hpp>
#include <nav_msgs/msg/odometry.hpp>

#include "motor_controller/pid_controller.hpp"

using namespace std::chrono_literals;

namespace
{
// Wraps an angle (in radians) into the range [-pi, pi].
double normalize_angle(double a)
{
  while (a > M_PI) a -= 2.0 * M_PI;
  while (a < -M_PI) a += 2.0 * M_PI;
  return a;
}
}  // namespace

class ColorMotorController : public rclcpp::Node
{
public:
  ColorMotorController() : Node("color_motor_controller")
  {
    declare_parameters();
    read_parameters();

    wall_pid_.set_gains(pid_kp_, pid_ki_, pid_kd_);
    wall_pid_.set_limits(pid_integral_clamp_, pid_output_clamp_);

    color_subscriber_ = this->create_subscription<std_msgs::msg::String>(
      "/detected_color", 10,
      std::bind(&ColorMotorController::color_callback, this, std::placeholders::_1));

    tof_front_subscriber_ = this->create_subscription<sensor_msgs::msg::LaserScan>(
      "/tof_front", rclcpp::SensorDataQoS(),
      std::bind(&ColorMotorController::front_callback, this, std::placeholders::_1));

    tof_rear_subscriber_ = this->create_subscription<sensor_msgs::msg::LaserScan>(
      "/tof_back", rclcpp::SensorDataQoS(),
      std::bind(&ColorMotorController::rear_callback, this, std::placeholders::_1));

    tof_left_subscriber_ = this->create_subscription<sensor_msgs::msg::LaserScan>(
      "/tof_left", rclcpp::SensorDataQoS(),
      std::bind(&ColorMotorController::left_callback, this, std::placeholders::_1));

    tof_right_subscriber_ = this->create_subscription<sensor_msgs::msg::LaserScan>(
      "/tof_right", rclcpp::SensorDataQoS(),
      std::bind(&ColorMotorController::right_callback, this, std::placeholders::_1));

    imu_subscriber_ = this->create_subscription<sensor_msgs::msg::Imu>(
      "/imu", rclcpp::SensorDataQoS(),
      std::bind(&ColorMotorController::imu_callback, this, std::placeholders::_1));

    odom_subscriber_ = this->create_subscription<nav_msgs::msg::Odometry>(
      "/odom", rclcpp::SensorDataQoS(),
      std::bind(&ColorMotorController::odom_callback, this, std::placeholders::_1));

    cmd_vel_publisher_ = this->create_publisher<geometry_msgs::msg::Twist>("/cmd_vel", 10);

    rclcpp::QoS lap_complete_qos(1);
    lap_complete_qos.transient_local();
    lap_complete_qos.reliable();
    lap_complete_publisher_ = this->create_publisher<std_msgs::msg::Bool>("/lap_complete", lap_complete_qos);

    fsm_state_publisher_ = this->create_publisher<std_msgs::msg::String>(
      "/fsm_state", rclcpp::QoS(10).best_effort());

    auto period = std::chrono::duration<double>(1.0 / control_loop_hz_);
    timer_ = this->create_wall_timer(
      std::chrono::duration_cast<std::chrono::milliseconds>(period),
      std::bind(&ColorMotorController::timer_callback, this));

    RCLCPP_INFO(this->get_logger(), "Color Motor Controller started (challenge_mode=%s)",
      challenge_mode_.c_str());
  }

private:
  // Top-level FSM states governing robot behavior.
  enum class State { STRAIGHT_DRIVING, TURNING, OBSTACLE_AVOIDANCE, FINISH };

  // Preferred turning direction, resolved once and optionally locked for the run.
  enum class TurnDir { UNKNOWN, LEFT, RIGHT };

  // Side to steer toward when avoiding a colored obstacle.
  enum class AvoidDir { LEFT, RIGHT };

  // Selects whether yaw is read from absolute IMU orientation or integrated gyro data.
  enum class YawSource { UNKNOWN, ABSOLUTE_ORIENTATION, GYRO_INTEGRATED };

  // -----------------------------------------------------------------------
  //  Parameter declaration and loading
  // -----------------------------------------------------------------------

  void declare_parameters()
  {
    this->declare_parameter<std::string>("challenge_mode", "open");

    this->declare_parameter<double>("pid.kp", 2.0);
    this->declare_parameter<double>("pid.ki", 0.0);
    this->declare_parameter<double>("pid.kd", 0.3);
    this->declare_parameter<double>("pid.integral_clamp", 0.3);
    this->declare_parameter<double>("pid.output_clamp", 1.0);

    this->declare_parameter<double>("wall_loss_threshold", 1.5);
    this->declare_parameter<double>("yaw_hold_kp", 1.5);

    this->declare_parameter<double>("speed.straight", 0.75);
    this->declare_parameter<double>("speed.turning", 0.15);
    this->declare_parameter<double>("speed.avoidance", 0.35);
    this->declare_parameter<double>("speed.max_linear", 0.9);
    this->declare_parameter<double>("angular.max", 1.2);

    this->declare_parameter<double>("turn.front_trigger_dist", 0.40);
    this->declare_parameter<double>("turn.yaw_error_thresh_deg", 10.0);
    this->declare_parameter<double>("turn.front_clear_dist", 0.60);
    this->declare_parameter<double>("turn.lateral_align_thresh", 0.05);
    this->declare_parameter<int>("turn.required_votes", 2);
    this->declare_parameter<double>("turn.angular_speed", 0.9);
    this->declare_parameter<int>("turn.total_turns_for_finish", 12);
    this->declare_parameter<bool>("turn.direction_lock", true);

    this->declare_parameter<double>("avoid.front_reengage_dist", 0.40);
    this->declare_parameter<double>("avoid.steer_angle", 0.5);
    this->declare_parameter<double>("avoid.recenter_lateral_thresh", 0.08);
    this->declare_parameter<double>("avoid.max_recenter_wait_sec", 1.0);
    this->declare_parameter<double>("avoid.deadzone_duration_sec", 1.5);

    this->declare_parameter<double>("safety.min_front_dist", 0.12);
    this->declare_parameter<double>("safety.min_side_dist", 0.06);
    this->declare_parameter<double>("safety.side_recover_angular", 1.2);

    this->declare_parameter<double>("imu.calib_duration_sec", 1.0);
    this->declare_parameter<int>("imu.min_calib_samples", 20);

    this->declare_parameter<double>("odom.stall_speed_thresh", 0.03);
    this->declare_parameter<double>("odom.stall_duration_sec", 0.75);
    this->declare_parameter<double>("magenta.deadzone_sec", 3.0);

    this->declare_parameter<double>("control_loop_hz", 50.0);
  }

  void read_parameters()
  {
    challenge_mode_ = this->get_parameter("challenge_mode").as_string();

    pid_kp_ = this->get_parameter("pid.kp").as_double();
    pid_ki_ = this->get_parameter("pid.ki").as_double();
    pid_kd_ = this->get_parameter("pid.kd").as_double();
    pid_integral_clamp_ = this->get_parameter("pid.integral_clamp").as_double();
    pid_output_clamp_ = this->get_parameter("pid.output_clamp").as_double();

    wall_loss_threshold_ = this->get_parameter("wall_loss_threshold").as_double();
    yaw_hold_kp_ = this->get_parameter("yaw_hold_kp").as_double();

    speed_straight_ = this->get_parameter("speed.straight").as_double();
    speed_turning_ = this->get_parameter("speed.turning").as_double();
    speed_avoidance_ = this->get_parameter("speed.avoidance").as_double();
    speed_max_linear_ = this->get_parameter("speed.max_linear").as_double();
    angular_max_ = this->get_parameter("angular.max").as_double();

    turn_front_trigger_dist_ = this->get_parameter("turn.front_trigger_dist").as_double();
    turn_yaw_error_thresh_rad_ =
      this->get_parameter("turn.yaw_error_thresh_deg").as_double() * M_PI / 180.0;
    turn_front_clear_dist_ = this->get_parameter("turn.front_clear_dist").as_double();
    turn_lateral_align_thresh_ = this->get_parameter("turn.lateral_align_thresh").as_double();
    turn_required_votes_ = this->get_parameter("turn.required_votes").as_int();
    turn_angular_speed_ = this->get_parameter("turn.angular_speed").as_double();
    turn_total_turns_for_finish_ = this->get_parameter("turn.total_turns_for_finish").as_int();
    turn_direction_lock_ = this->get_parameter("turn.direction_lock").as_bool();

    avoid_front_reengage_dist_ = this->get_parameter("avoid.front_reengage_dist").as_double();
    avoid_steer_angle_ = this->get_parameter("avoid.steer_angle").as_double();
    avoid_recenter_lateral_thresh_ = this->get_parameter("avoid.recenter_lateral_thresh").as_double();
    avoid_max_recenter_wait_sec_ = this->get_parameter("avoid.max_recenter_wait_sec").as_double();
    avoid_deadzone_duration_sec_ = this->get_parameter("avoid.deadzone_duration_sec").as_double();

    safety_min_front_dist_ = this->get_parameter("safety.min_front_dist").as_double();
    safety_min_side_dist_ = this->get_parameter("safety.min_side_dist").as_double();
    safety_side_recover_angular_ = this->get_parameter("safety.side_recover_angular").as_double();

    imu_calib_duration_sec_ = this->get_parameter("imu.calib_duration_sec").as_double();
    imu_min_calib_samples_ = this->get_parameter("imu.min_calib_samples").as_int();

    odom_stall_speed_thresh_ = this->get_parameter("odom.stall_speed_thresh").as_double();
    odom_stall_duration_sec_ = this->get_parameter("odom.stall_duration_sec").as_double();
    magenta_deadzone_sec_ = this->get_parameter("magenta.deadzone_sec").as_double();

    control_loop_hz_ = this->get_parameter("control_loop_hz").as_double();
  }

  // -----------------------------------------------------------------------
  //  Sensor callbacks
  // -----------------------------------------------------------------------

  void color_callback(const std_msgs::msg::String::SharedPtr msg) { last_color_ = msg->data; }

  void front_callback(const sensor_msgs::msg::LaserScan::SharedPtr msg) { front_dist_ = get_min_valid(msg); }
  void rear_callback(const sensor_msgs::msg::LaserScan::SharedPtr msg)  { rear_dist_  = get_min_valid(msg); }
  void left_callback(const sensor_msgs::msg::LaserScan::SharedPtr msg)  { left_dist_  = get_min_valid(msg); }
  void right_callback(const sensor_msgs::msg::LaserScan::SharedPtr msg) { right_dist_ = get_min_valid(msg); }

  void odom_callback(const nav_msgs::msg::Odometry::SharedPtr msg)
  {
    measured_linear_x_ = msg->twist.twist.linear.x;
  }

  // Converts a unit quaternion to a yaw angle (rotation about Z) in radians.
  // Used when the IMU reports absolute orientation (e.g. BNO055 in NDOF mode
  // or a simulated ground-truth IMU). For raw 6-DOF sensors without a
  // magnetometer, yaw is obtained by integrating angular_velocity.z instead.
  //
  // IMU drivers signal "no orientation data" by setting orientation_covariance[0]
  // to -1 (per REP-145). We check this flag at startup to auto-select the yaw
  // source, keeping the same code path valid for both hardware configurations.
  static double quaternion_to_yaw(const geometry_msgs::msg::Quaternion & q)
  {
    return std::atan2(2.0 * (q.w * q.z + q.x * q.y), 1.0 - 2.0 * (q.y * q.y + q.z * q.z));
  }

  void imu_callback(const sensor_msgs::msg::Imu::SharedPtr msg)
  {
    rclcpp::Time stamp(msg->header.stamp);
    bool orientation_valid = msg->orientation_covariance[0] != -1.0;

    // Determine yaw source on the first IMU message received.
    if (yaw_source_ == YawSource::UNKNOWN) {
      yaw_source_ = orientation_valid ? YawSource::ABSOLUTE_ORIENTATION : YawSource::GYRO_INTEGRATED;
      RCLCPP_INFO(this->get_logger(), "IMU yaw source: %s",
        yaw_source_ == YawSource::ABSOLUTE_ORIENTATION
          ? "absolute orientation from IMU (fused, e.g. BNO055 NDOF)"
          : "gyro integration with startup bias calibration (raw IMU, e.g. MPU-6050)");
    }

    // For fusion-capable IMUs the orientation quaternion is already trustworthy;
    // extract yaw directly and skip the bias-calibration phase entirely.
    if (yaw_source_ == YawSource::ABSOLUTE_ORIENTATION) {
      yaw_ = normalize_angle(quaternion_to_yaw(msg->orientation));
      imu_calibrated_ = true;
      return;
    }

    // Gyro-integration path: collect samples during the startup window to
    // estimate the static bias of the Z-axis gyroscope before integrating.
    if (!imu_calibrated_) {
      if (!calib_started_) {
        calib_start_time_ = stamp;
        calib_started_ = true;
      }
      calib_sum_ += msg->angular_velocity.z;
      calib_count_++;

      double elapsed = (stamp - calib_start_time_).seconds();
      if (elapsed >= imu_calib_duration_sec_) {
        if (calib_count_ >= imu_min_calib_samples_) {
          gyro_z_bias_ = calib_sum_ / static_cast<double>(calib_count_);
        } else {
          // Too few samples collected — fall back to zero bias and warn the operator.
          RCLCPP_WARN(this->get_logger(),
            "IMU bias calibration only collected %d samples (< %d), defaulting bias to 0",
            calib_count_, imu_min_calib_samples_);
          gyro_z_bias_ = 0.0;
        }
        imu_calibrated_ = true;
        last_imu_time_ = stamp;
        RCLCPP_INFO(this->get_logger(), "IMU yaw bias calibrated: %.5f rad/s (%d samples)",
          gyro_z_bias_, calib_count_);
      }
      return;
    }

    // Integrate bias-corrected angular velocity to maintain a running yaw estimate.
    double dt = (stamp - last_imu_time_).seconds();
    last_imu_time_ = stamp;
    if (dt <= 0.0) return;

    yaw_ = normalize_angle(yaw_ + (msg->angular_velocity.z - gyro_z_bias_) * dt);
  }

  // Returns the smallest finite range reading within the sensor's valid interval.
  // Out-of-range, NaN, and Inf readings are discarded.
  double get_min_valid(const sensor_msgs::msg::LaserScan::SharedPtr & msg)
  {
    double min_r = msg->range_max;
    for (const auto & r : msg->ranges) {
      if (std::isfinite(r) && r >= msg->range_min && r <= msg->range_max && r < min_r) {
        min_r = r;
      }
    }
    return min_r;
  }

  // Returns true only after the IMU is calibrated and all four ToF sensors have
  // reported at least one valid reading. The control loop is held idle until this
  // guard passes to avoid acting on stale or uninitialized sensor data.
  bool sensors_ready() const
  {
    return imu_calibrated_ && front_dist_ >= 0.0 && left_dist_ >= 0.0 && right_dist_ >= 0.0;
  }

  // -----------------------------------------------------------------------
  //  FSM state transitions
  // -----------------------------------------------------------------------

  // Returns true if we are within the post-avoidance deadzone window, during
  // which a new obstacle avoidance maneuver must not be started. This prevents
  // the robot from re-triggering avoidance on the same obstacle immediately
  // after returning to straight driving.
  bool in_avoid_deadzone() const
  {
    if (!has_last_avoid_end_time_) return false;
    return (this->now() - last_avoid_end_time_).seconds() < avoid_deadzone_duration_sec_;
  }

  void enter_turning()
  {
    state_ = State::TURNING;
    turn_reference_yaw_ = yaw_;
    turn_fusion_consecutive_ = 0;

    // Reset the wall PID before the turn so that its derivative term is not
    // computed against a pre-turn error on the first control tick after returning
    // to straight driving. Without this reset, the large stale error difference
    // produces a spurious angular kick that is consistently biased in the same
    // direction (corner geometry repeats each lap), causing progressive
    // wall-ward drift over successive laps.
    wall_pid_.reset();

    // Resolve turn direction on the first turn; re-evaluate if direction lock is off.
    if (turn_dir_ == TurnDir::UNKNOWN || !turn_direction_lock_) {
      TurnDir decided = (left_dist_ > right_dist_) ? TurnDir::LEFT : TurnDir::RIGHT;
      if (turn_dir_ == TurnDir::UNKNOWN) {
        RCLCPP_INFO(this->get_logger(), "Turn direction locked: %s",
          decided == TurnDir::LEFT ? "LEFT" : "RIGHT");
      }
      turn_dir_ = decided;
    }
  }

  void enter_obstacle_avoidance()
  {
    state_ = State::OBSTACLE_AVOIDANCE;
    // GREEN → steer right (pass obstacle on the left); all other colors → steer left.
    avoid_dir_ = (last_color_ == "GREEN") ? AvoidDir::RIGHT : AvoidDir::LEFT;
    avoid_cleared_ = false;
    // Reset PID for the same reason as in enter_turning().
    wall_pid_.reset();
    RCLCPP_INFO(this->get_logger(), "Obstacle avoidance: color=%s steer=%s",
      last_color_.c_str(), avoid_dir_ == AvoidDir::LEFT ? "LEFT" : "RIGHT");
  }

  void enter_finish()
  {
    state_ = State::FINISH;
    // Publish the lap-complete flag exactly once with a latched QoS so late
    // subscribers still receive it.
    if (!lap_complete_published_) {
      std_msgs::msg::Bool msg;
      msg.data = true;
      lap_complete_publisher_->publish(msg);
      lap_complete_published_ = true;
      RCLCPP_INFO(this->get_logger(), "FINISH: %d turns completed, lap_complete published",
        turn_count_);
    }
  }

  // Multi-criteria turn-completion check using a simple voting scheme.
  // A turn is considered done when at least turn_required_votes_ of the three
  // independent conditions are satisfied simultaneously:
  //   1. Yaw error to the 90-degree target is within the angular threshold.
  //   2. The front sensor reads clear (no wall directly ahead).
  //   3. Left and right distances are approximately balanced (corridor alignment).
  bool check_turn_fusion_votes() const
  {
    double dir_sign = (turn_dir_ == TurnDir::LEFT) ? 1.0 : -1.0;
    double target_yaw = normalize_angle(turn_reference_yaw_ + dir_sign * (M_PI / 2.0));
    double yaw_error = std::fabs(normalize_angle(target_yaw - yaw_));

    int votes = 0;
    if (yaw_error < turn_yaw_error_thresh_rad_) votes++;
    if (front_dist_ > turn_front_clear_dist_) votes++;
    if (std::fabs(left_dist_ - right_dist_) < turn_lateral_align_thresh_) votes++;

    return votes >= turn_required_votes_;
  }

  // Evaluates and executes FSM transitions based on the current sensor readings.
  // Called once per control cycle before the output is computed.
  void evaluate_transitions()
  {
    switch (state_) {
      case State::STRAIGHT_DRIVING: {
        if (challenge_mode_ == "obstacle") {
          // Magenta markers count as four turns (one full side of the track).
          // A deadzone prevents double-counting a single marker pass.
          bool in_magenta_deadzone = magenta_counted_this_pass_ &&
            (this->now() - last_magenta_count_time_).seconds() < magenta_deadzone_sec_;
          if (last_color_ == "MAGENTA" && !in_magenta_deadzone) {
            turn_count_ += 4;
            magenta_counted_this_pass_ = true;
            last_magenta_count_time_ = this->now();
            if (turn_count_ >= turn_total_turns_for_finish_) {
              enter_finish();
              break;
            }
          }
        }
        if (front_dist_ < turn_front_trigger_dist_) {
          enter_turning();
        } else if (
          challenge_mode_ == "obstacle" &&
          last_color_ != "NONE" &&
          last_color_ != "MAGENTA" &&
          front_dist_ > avoid_front_reengage_dist_ &&
          !in_avoid_deadzone())
        {
          enter_obstacle_avoidance();
        }
        break;
      }

      case State::TURNING: {
        // Require two consecutive passing votes to avoid premature exit on
        // transient sensor noise near the turn completion boundary.
        if (check_turn_fusion_votes()) {
          turn_fusion_consecutive_++;
          if (turn_fusion_consecutive_ >= 2) {
            turn_fusion_consecutive_ = 0;
            if (challenge_mode_ != "obstacle") {
              turn_count_++;
            }
            if (turn_count_ >= turn_total_turns_for_finish_) {
              enter_finish();
            } else {
              state_ = State::STRAIGHT_DRIVING;
              heading_hold_ = yaw_;
            }
          }
        } else {
          turn_fusion_consecutive_ = 0;
        }
        break;
      }

      case State::OBSTACLE_AVOIDANCE: {
        // A wall at turn-trigger distance takes priority over the re-centering
        // wait. The lane geometry is changing at corners, so delegating to the
        // TURNING state's fusion-based completion logic is more reliable than
        // waiting for lateral alignment that may never be achieved this close
        // to a corner wall.
        if (front_dist_ < turn_front_trigger_dist_) {
          enter_turning();
          break;
        }

        if (last_color_ == "NONE") {
          // Mark the moment the obstacle marker first disappears from the sensor.
          if (!avoid_cleared_) {
            avoid_cleared_ = true;
            avoid_cleared_time_ = this->now();
          }

          bool wall_aligned = std::fabs(left_dist_ - right_dist_) < avoid_recenter_lateral_thresh_;
          bool wait_timed_out =
            (this->now() - avoid_cleared_time_).seconds() > avoid_max_recenter_wait_sec_;

          // Return to straight driving once the robot is laterally re-centered in
          // the corridor, or after the recenter timeout expires.
          if (wall_aligned || wait_timed_out) {
            state_ = State::STRAIGHT_DRIVING;
            heading_hold_ = yaw_;
            last_avoid_end_time_ = this->now();
            has_last_avoid_end_time_ = true;
            avoid_cleared_ = false;
          }
        } else {
          // The color signal flickered back — the robot is still grazing the
          // obstacle. Reset the recenter-wait clock to avoid exiting too early.
          avoid_cleared_ = false;
        }
        break;
      }

      case State::FINISH:
        break;
    }
  }

  // -----------------------------------------------------------------------
  //  Control output computation
  // -----------------------------------------------------------------------

  // Computes the angular velocity command for wall-centering during straight
  // driving. Blends PID-based wall-following with a yaw-hold fallback whose
  // weight depends on how many side walls are currently in range.
  double compute_wall_centering_angular(double dt)
  {
    bool left_valid  = left_dist_  < wall_loss_threshold_;
    bool right_valid = right_dist_ < wall_loss_threshold_;

    double weight_wall;
    if (left_valid && right_valid) {
      // Both walls visible: full PID authority, keep heading synchronized.
      weight_wall = 1.0;
      heading_hold_ = yaw_;
    } else if (left_valid || right_valid) {
      // Only one wall visible: split authority equally between PID and yaw hold.
      weight_wall = 0.5;
    } else {
      // No walls in range: rely entirely on the stored heading reference.
      weight_wall = 0.0;
    }

    double pid_term = wall_pid_.update(left_dist_ - right_dist_, dt);
    double yaw_term = yaw_hold_kp_ * normalize_angle(heading_hold_ - yaw_);

    return weight_wall * pid_term + (1.0 - weight_wall) * yaw_term;
  }

  // Returns the raw (pre-safety-guard) Twist command for the active FSM state.
  geometry_msgs::msg::Twist compute_state_output(double dt)
  {
    geometry_msgs::msg::Twist t;
    switch (state_) {
      case State::STRAIGHT_DRIVING:
        t.linear.x  = speed_straight_;
        t.angular.z = compute_wall_centering_angular(dt);
        break;

      case State::TURNING:
        t.linear.x  = speed_turning_;
        t.angular.z = (turn_dir_ == TurnDir::LEFT ? 1.0 : -1.0) * turn_angular_speed_;
        break;

      case State::OBSTACLE_AVOIDANCE:
        t.linear.x  = speed_avoidance_;
        t.angular.z = (avoid_dir_ == AvoidDir::LEFT ? 1.0 : -1.0) * avoid_steer_angle_;
        break;

      case State::FINISH:
        t.linear.x  = 0.0;
        t.angular.z = 0.0;
        break;
    }
    return t;
  }

  // Overrides the computed Twist with emergency stop or recovery commands when
  // proximity thresholds are violated. FINISH state bypasses all guards because
  // the robot must remain stationary regardless of sensor readings.
  geometry_msgs::msg::Twist apply_safety_guards(geometry_msgs::msg::Twist t)
  {
    if (state_ == State::FINISH) return t;

    // Hard stop if the front wall is critically close.
    if (front_dist_ < safety_min_front_dist_) {
      t.linear.x  = 0.0;
      t.angular.z = 0.0;
      return t;
    }

    // Side-wall emergency: stop forward motion and apply a corrective rotation
    // away from whichever side (or both) has violated the minimum clearance.
    bool emergency = false;
    double emergency_angular = 0.0;
    if (right_dist_ < safety_min_side_dist_) {
      emergency_angular += safety_side_recover_angular_;
      emergency = true;
    }
    if (left_dist_ < safety_min_side_dist_) {
      emergency_angular -= safety_side_recover_angular_;
      emergency = true;
    }
    if (emergency) {
      t.linear.x  = 0.0;
      t.angular.z = emergency_angular;
    }

    return t;
  }

  // Saturates linear and angular velocity commands to their configured maximums.
  void clamp_twist(geometry_msgs::msg::Twist & t) const
  {
    t.linear.x  = std::clamp(t.linear.x,  -speed_max_linear_, speed_max_linear_);
    t.angular.z = std::clamp(t.angular.z, -angular_max_,      angular_max_);
  }

  // Detects a motor stall by comparing the commanded and measured linear speeds.
  // Logs a throttled warning when the robot appears to be commanded to move but
  // is not actually accelerating past the stall threshold.
  void check_stall(double now_sec)
  {
    bool trying_to_move = std::fabs(commanded_linear_x_) > odom_stall_speed_thresh_;
    bool not_moving     = std::fabs(measured_linear_x_)  < odom_stall_speed_thresh_;

    if (trying_to_move && not_moving) {
      if (!stall_timer_active_) {
        stall_start_sec_    = now_sec;
        stall_timer_active_ = true;
      } else if (now_sec - stall_start_sec_ > odom_stall_duration_sec_) {
        RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 2000,
          "Possible stall: commanded_linear_x=%.2f measured_linear_x=%.2f",
          commanded_linear_x_, measured_linear_x_);
      }
    } else {
      stall_timer_active_ = false;
    }
  }

  // Returns a human-readable label for the active FSM state.
  std::string state_str() const
  {
    switch (state_) {
      case State::STRAIGHT_DRIVING:   return "STRAIGHT_DRIVING";
      case State::TURNING:            return "TURNING";
      case State::OBSTACLE_AVOIDANCE: return "OBSTACLE_AVOIDANCE";
      case State::FINISH:             return "FINISH";
    }
    return "UNKNOWN";
  }

  // Publishes the current FSM state and turn counter for external monitoring
  // and diagnostics (e.g. rqt, rosbag replay analysis).
  void publish_fsm_state()
  {
    std_msgs::msg::String msg;
    std::ostringstream oss;
    oss << state_str() << " turn=" << turn_count_ << "/" << turn_total_turns_for_finish_;
    msg.data = oss.str();
    fsm_state_publisher_->publish(msg);
  }

  // -----------------------------------------------------------------------
  //  Main control loop
  // -----------------------------------------------------------------------

  void timer_callback()
  {
    // Hold all outputs at zero until every sensor has delivered its first
    // valid reading and the IMU bias calibration window has elapsed.
    if (!sensors_ready()) {
      cmd_vel_publisher_->publish(geometry_msgs::msg::Twist());
      return;
    }

    rclcpp::Time now = this->now();

    // Use the nominal dt as the initial estimate; replace it with the measured
    // inter-tick interval as soon as a previous timestamp is available.
    double dt = 1.0 / control_loop_hz_;
    if (has_last_control_time_) {
      double measured_dt = (now - last_control_time_).seconds();
      if (measured_dt > 0.0) dt = measured_dt;
    }
    last_control_time_     = now;
    has_last_control_time_ = true;

    // FSM transitions are frozen once FINISH is reached.
    if (state_ != State::FINISH) {
      evaluate_transitions();
    }

    geometry_msgs::msg::Twist candidate    = compute_state_output(dt);
    geometry_msgs::msg::Twist final_twist  = apply_safety_guards(candidate);
    clamp_twist(final_twist);

    cmd_vel_publisher_->publish(final_twist);
    publish_fsm_state();

    commanded_linear_x_ = final_twist.linear.x;
    check_stall(now.seconds());
  }

  // -----------------------------------------------------------------------
  //  Cached ROS parameters
  // -----------------------------------------------------------------------

  std::string challenge_mode_;

  double pid_kp_, pid_ki_, pid_kd_, pid_integral_clamp_, pid_output_clamp_;
  double wall_loss_threshold_, yaw_hold_kp_;
  double speed_straight_, speed_turning_, speed_avoidance_, speed_max_linear_, angular_max_;

  double turn_front_trigger_dist_, turn_yaw_error_thresh_rad_, turn_front_clear_dist_;
  double turn_lateral_align_thresh_, turn_angular_speed_;
  int    turn_required_votes_, turn_total_turns_for_finish_;
  bool   turn_direction_lock_;

  double avoid_front_reengage_dist_, avoid_steer_angle_, avoid_recenter_lateral_thresh_;
  double avoid_max_recenter_wait_sec_, avoid_deadzone_duration_sec_;

  double safety_min_front_dist_, safety_min_side_dist_, safety_side_recover_angular_;

  double imu_calib_duration_sec_;
  int    imu_min_calib_samples_;

  double odom_stall_speed_thresh_, odom_stall_duration_sec_;
  double magenta_deadzone_sec_;

  double control_loop_hz_;

  // -----------------------------------------------------------------------
  //  Runtime state
  // -----------------------------------------------------------------------

  State   state_    = State::STRAIGHT_DRIVING;
  TurnDir turn_dir_ = TurnDir::UNKNOWN;
  AvoidDir avoid_dir_ = AvoidDir::LEFT;

  int    turn_count_             = 0;
  int    turn_fusion_consecutive_ = 0;
  double turn_reference_yaw_     = 0.0;
  double heading_hold_           = 0.0;

  bool         has_last_avoid_end_time_ = false;
  rclcpp::Time last_avoid_end_time_;

  bool         avoid_cleared_      = false;
  rclcpp::Time avoid_cleared_time_;

  bool lap_complete_published_ = false;

  bool         magenta_counted_this_pass_ = false;
  rclcpp::Time last_magenta_count_time_;

  double      front_dist_  = -1.0;
  double      rear_dist_   = -1.0;
  double      left_dist_   = -1.0;
  double      right_dist_  = -1.0;
  std::string last_color_  = "NONE";

  double measured_linear_x_  = 0.0;
  double commanded_linear_x_ = 0.0;
  bool   stall_timer_active_ = false;
  double stall_start_sec_    = 0.0;

  double    yaw_        = 0.0;
  YawSource yaw_source_ = YawSource::UNKNOWN;
  double    gyro_z_bias_  = 0.0;
  bool      imu_calibrated_ = false;
  bool      calib_started_  = false;
  rclcpp::Time calib_start_time_;
  rclcpp::Time last_imu_time_;
  double calib_sum_   = 0.0;
  int    calib_count_ = 0;

  bool         has_last_control_time_ = false;
  rclcpp::Time last_control_time_;

  motor_controller::PidController wall_pid_;

  // -----------------------------------------------------------------------
  //  ROS 2 interfaces
  // -----------------------------------------------------------------------

  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr      color_subscriber_;
  rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr tof_front_subscriber_;
  rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr tof_rear_subscriber_;
  rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr tof_left_subscriber_;
  rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr tof_right_subscriber_;
  rclcpp::Subscription<sensor_msgs::msg::Imu>::SharedPtr       imu_subscriber_;
  rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr     odom_subscriber_;

  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr  cmd_vel_publisher_;
  rclcpp::Publisher<std_msgs::msg::Bool>::SharedPtr        lap_complete_publisher_;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr      fsm_state_publisher_;

  rclcpp::TimerBase::SharedPtr timer_;
};

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<ColorMotorController>());
  rclcpp::shutdown();
  return 0;
}