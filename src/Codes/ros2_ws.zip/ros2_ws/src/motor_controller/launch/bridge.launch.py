"""Bring up the ros_gz_bridge for the WRO 2026 FE sim plus both motor_controller nodes.

Assumes Gazebo is already running separately (per ~/Desktop/wro2026_sim/README.md,
untouched Workspace 1) -- this file does not launch `gz sim` itself.
"""

import os

from ament_index_python.packages import get_package_share_directory

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from ros_gz_bridge.actions import RosGzBridge


def generate_launch_description():
    pkg_share = get_package_share_directory('motor_controller')
    bridge_config = os.path.join(pkg_share, 'config', 'bridge.yaml')
    params_file = os.path.join(pkg_share, 'config', 'params.yaml')

    use_sim_time_arg = DeclareLaunchArgument(
        'use_sim_time', default_value='true',
        description='Use /clock from Gazebo instead of wall time'
    )
    challenge_mode_arg = DeclareLaunchArgument(
        'challenge_mode', default_value='open',
        description='FSM challenge mode: "open" or "obstacle"'
    )

    use_sim_time = LaunchConfiguration('use_sim_time')
    challenge_mode = LaunchConfiguration('challenge_mode')

    bridge = RosGzBridge(
        bridge_name='ros_gz_bridge',
        config_file=bridge_config,
        extra_bridge_params={'use_sim_time': use_sim_time},
    )

    color_motor_controller_node = Node(
        package='motor_controller',
        executable='color_motor_controller',
        name='color_motor_controller',
        output='screen',
        parameters=[
            params_file,
            {'use_sim_time': use_sim_time},
            {'challenge_mode': challenge_mode},
        ],
    )

    camera_subscriber_node = Node(
        package='motor_controller',
        executable='motor_controller.py',
        name='camera_subscriber',
        output='screen',
        parameters=[
            params_file,
            {'use_sim_time': use_sim_time},
        ],
    )

    return LaunchDescription([
        use_sim_time_arg,
        challenge_mode_arg,
        bridge,
        color_motor_controller_node,
        camera_subscriber_node,
    ])
